import sys

s = sys.stdin.read()
print 'OK'
