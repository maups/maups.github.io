# ---------------------------------------------------------------------------------------------------------- #
# Author: maups                                                                                              #
# ---------------------------------------------------------------------------------------------------------- #
import sys
import os

# ---------------------------------------------------------------------------------------------------------- #
# Linha de comando:                                                                                          #
#         python3 test.py /path/to/test_folder /path/to/output.txt                                           #
# Descrição:                                                                                                 #
#         * carrega todas as imagens no diretório /path/to/test_folder                                       #
#         * para cada imagem carregada, imprime uma linha no arquivo /path/to/output.txt com dois valores    #
#           separados por um espaço, sendo eles o nome do arquivo da imagem seguido do nome da sua           #
#           respectiva classe ('futebol', 'golfe', 'sinuca' ou 'tenis')                                      #
# ---------------------------------------------------------------------------------------------------------- #

############################################
# CARREGAR MODELO DE CLASSIFICAÇÃO AQUI!!! #
############################################

test_images = sorted(os.listdir(sys.argv[1]))

fp = open(sys.argv[2], 'w')

for i in range(len(test_images)):

	#################################################
	# INÍCIO DO SEU CÓDIGO DE CLASSIFICAÇÃO AQUI!!! #
	c = 'futebol'
	# FIM DO SEU CÓDIGO DE CLASSIFICAÇÃO AQUI!!!    #
	#################################################

	fp.write(test_images[i] + ' ' + c + '\n')

fp.close()

