#include <bits/stdc++.h>

using namespace std;

char buf[555555];

int main() {
	int n = fread(buf, sizeof(char), 555554, stdin);
	cout << "OK" << endl;
	return 0;
}
